<p
  align="center" 
  style="box-shadow: 2px 2px;"
>
  <a 
    href="https://material-table.com" 
    rel="noopener" 
    target="_blank"
  >
    <img 
      width="200" 
      src="https://raw.githubusercontent.com/mbrn/material-table.com/master/docs/assets/logo-back.png" 
      alt="material-table" 
    />
  </a>
</p>

<h1 align="center">
  🛣️ Material Table Roadmap 🛣️
</h1>

<small>
  last updated: June 6, 2020
</small>

<p align="center">
  <i>
    <b>
    Currently, we would like to gain control of open issues and smaller pull requests. Once we have control of issues and PR's we will begin to entertain new features and enhancements.
    </b>
  </i>
</p>

---

<h3 align="center">
  🚧 Help Wanted 🚧
</h3>

<p align="center">
  <i>
  If you have some free time and would like to contribute, we always welcome help with open issues and/or pull requests to help resolve open issues.
  </i>
</p>
