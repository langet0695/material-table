# Contributing

1. Fork the repo
2. Create your feature or bug branch : `git checkout -b feature/my-new-feature`
3. Commit your changes: `git commit -m 'Add some feature'`
4. Push to the branch: `git push origin feature/my-new-feature`

**After your pull request is merged**, you can safely delete your branch.

### [<- Back](https://github.com/mbrn/material-table/)
