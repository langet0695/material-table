"use strict";
if (!Array.prototype.find) {
  require("./array.find");
}
